#!/bin/bash

# programa que recibe la variable $nombre del archivo 2_variables.sh

echo "Variable declara desde otro archivo $nombre"
