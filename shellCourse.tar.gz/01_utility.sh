#!/bin/bash

# autor: programador negro

echo "Curso de programacion en bash" |  lolcat

