#!/bin/bash

# descargar archivos de internet
# autor: programador negro

echo "Descargar informacion de internet"

# descargara un PDF de la pagina de -library
wget https://es.b-ok.lat/dl/1107931/c0b2ac?dsource=mostpopular